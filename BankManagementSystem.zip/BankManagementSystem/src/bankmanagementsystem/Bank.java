package bankmanagementsystem;

import java.awt.HeadlessException;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class Bank {

    private static ArrayList<Customer> customers;

    static {
        customers = new ArrayList<>();
    }

    public static void display(String msg) {
        JOptionPane.showMessageDialog(null, msg);
    }

    public static boolean depositMoney(String name, String accountNum, String password, double amount) {
        File file = new File("AddedCustomers.txt");

        ArrayList<String> lines = new ArrayList<>();
        boolean found = false;
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (!line.isEmpty()) {
                    String[] parts = line.split("\\|");
                    if (parts.length > 8) {
                        try {
                            if (parts[0].trim().equalsIgnoreCase(name)
                                    && parts[7].trim().equals(accountNum)
                                    && parts[8].trim().equalsIgnoreCase(password)) {
                                parts[6] = (Double.parseDouble(parts[6].trim()) + amount) + "";
                                found = true;
                            }
                            lines.add(String.join("|", parts));
                        } catch (NumberFormatException e) {
                            e.printStackTrace();
                            lines.add(line);
                        }
                    } else {
                        lines.add(line);
                    }
                }
            }
            if (!found) {
                JOptionPane.showMessageDialog(null, "Credentials not found");
            }
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
            for (String updatedLine : lines) {
                writer.write(updatedLine);
                writer.newLine();
            }
            return found;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean withdrawMoney(String name, String accountNum, String password, double amount) {
        File file = new File("AddedCustomers.txt");

        ArrayList<String> lines = new ArrayList<>();
        boolean found = false;
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (!line.isEmpty()) {
                    String[] parts = line.split("\\|");
                    if (parts.length > 8) {
                        try {
                            if (parts[0].trim().equalsIgnoreCase(name)
                                    && parts[7].trim().equals(accountNum)
                                    && parts[8].trim().equalsIgnoreCase(password)) {
                                if (Double.parseDouble(parts[6].trim()) > amount) {
                                    parts[6] = (Double.parseDouble(parts[6].trim()) - amount) + "";
                                    found = true;
                                } else {
                                    display("Insufficent amount the avaliable amount is " + parts[6]);
                                    return false;
                                }
                            }
                            lines.add(String.join("|", parts));
                        } catch (NumberFormatException e) {
                            e.printStackTrace();
                            lines.add(line);
                        }
                    } else {
                        lines.add(line);
                    }
                }
            }
            if (!found) {
                JOptionPane.showMessageDialog(null, "Credentials not found");
            }
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
            for (String updatedLine : lines) {
                writer.write(updatedLine);
                writer.newLine();
            }
            return found;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }

    }

    public static List<String> listOfCustomers() {
        List<String> lines = new ArrayList<>();
        File file = new File("AddedCustomers.txt");

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                lines.add(line.trim());
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }

        return lines;
    }

    public static boolean transferMoney(String sourceName, String sourceAccountNum, String sourcePassword, String destinationName, String destinationAccountNum, double amount) {
        File file = new File("AddedCustomers.txt");
        ArrayList<String> lines = new ArrayList<>();
        boolean sourceFound = false;
        boolean destinationFound = false;
        String[] sourceAccountData = null;
        String[] destinationAccountData = null;
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (!line.isEmpty()) {
                    String[] parts = line.split("\\|");
                    if (parts.length > 8) {
                        if (parts[0].trim().equalsIgnoreCase(sourceName) && parts[7].trim().equals(sourceAccountNum) && parts[8].trim().equalsIgnoreCase(sourcePassword)) {
                            double currentBalance = Double.parseDouble(parts[6].trim());
                            if (currentBalance >= amount) {
                                parts[6] = (currentBalance - amount) + "";
                                sourceAccountData = parts;
                                sourceFound = true;
                            } else {
                                display("Insufficient funds in source account. Available balance: " + parts[6]);
                                return false;
                            }
                        }
                        if (parts[0].trim().equals(destinationName) && parts[7].trim().equals(destinationAccountNum)) {
                            double currentBalance = Double.parseDouble(parts[6].trim());
                            parts[6] = (currentBalance + amount) + "";
                            destinationAccountData = parts;
                            destinationFound = true;
                        }
                    }
                    lines.add(line);
                }
            }
            if (!sourceFound) {
                display("Source account not found or credentials incorrect.");
                return false;
            }
            if (!destinationFound) {
                display("Destination account not found.");
                return false;
            }
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
            for (String updatedLine : lines) {
                if (sourceAccountData != null && updatedLine.contains(sourceAccountNum)) {
                    writer.write(String.join("|", sourceAccountData));
                } else if (destinationAccountData != null && updatedLine.contains(destinationAccountNum)) {
                    writer.write(String.join("|", destinationAccountData));
                } else {
                    writer.write(updatedLine);
                }
                writer.newLine();
            }
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

}
